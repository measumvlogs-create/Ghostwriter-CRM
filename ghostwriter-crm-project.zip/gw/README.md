# GhostWriter CRM (Fastn hackathon)
- frontend/public/index.html : demo UI (simulated data, tenant switcher, Fastn widget panel, two-tenant test)
- supabase/migrations/001_schema.sql : schema + RLS (tenant_id on every table)
- supabase/functions/* : extract-meeting, fastn-embed-token, run-workflow
- supabase/seed_two_tenants.sql : create two tenants

## Deploy
1. supabase db push   (or paste 001_schema.sql in SQL editor)
2. Create 2 auth users, edit and run seed_two_tenants.sql
3. supabase secrets set --env-file .env
4. supabase functions deploy extract-meeting fastn-embed-token run-workflow

## Status
NOT done: React/TS rewrite, wiring index.html to Supabase/functions, real OAuth flows for the 5 connectors,
voice STT. Fastn endpoint URLs are env placeholders: fill from your Fastn workspace; they were not verified here.
