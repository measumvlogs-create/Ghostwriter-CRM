-- Run after creating two auth users (Dashboard > Auth). Replace the UUIDs.
with a as (insert into tenants(name) values ('Acme Realty') returning id), b as (insert into tenants(name) values ('Bright Consulting') returning id)
insert into profiles(id,tenant_id,email,full_name)
select 'USER_A_UUID', a.id, 'alice@acme-realty.com','Alice' from a
union all select 'USER_B_UUID', b.id, 'bob@brightco.io','Bob' from b;
-- Isolation proof: sign in as A, run the same workflow, then `select count(*) from contacts` must return only A's rows.
