// Runs the same Fastn workflow scoped to the caller tenant; logs the result per tenant.
// FASTN_WORKFLOW_URL: execute endpoint of your workflow (not verified here).
import { cors, ctx } from "../_shared/auth.ts";
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { user, tenantId } = await ctx(req);
    const { workflow = "post-meeting-sync", input = {} } = await req.json();
    const url = Deno.env.get("FASTN_WORKFLOW_URL");
    let status = "skipped", result: unknown = { note: "FASTN_WORKFLOW_URL not configured; nothing executed" };
    if (url) {
      const r = await fetch(url, { method: "POST", headers: { Authorization: `Bearer ${Deno.env.get("FASTN_API_KEY")}`, "content-type": "application/json" }, body: JSON.stringify({ tenantId, input }) });
      status = r.ok ? "ok" : "failed"; result = await r.json().catch(() => ({}));
    }
    await user.from("workflow_runs").insert({ tenant_id: tenantId, workflow, status, result });
    return new Response(JSON.stringify({ tenantId, status, result }), { headers: { ...cors, "content-type": "application/json" } });
  } catch (e) { return e instanceof Response ? e : new Response(String(e), { status: 500, headers: cors }); }
});
