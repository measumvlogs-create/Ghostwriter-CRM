import { cors, ctx } from "../_shared/auth.ts";
const SYSTEM = `Extract CRM data from meeting notes. Return ONLY JSON:
{"contact":{"full_name":null,"company":null,"email":null,"phone":null,"job_title":null},
"meeting":{"date":null,"summary":null,"key_points":[],"requirements":[],"pain_points":[],"budget":null,"purchase_intent":null,"sentiment":null},
"opportunity":{"title":null,"value":null,"stage":null,"expected_close":null},
"followups":[{"title":"","description":"","due_date":null,"priority":"medium","ai_suggested":true}],
"confidence":0.0}
Never invent missing info; use null. Mark inferred items ai_suggested=true.`;
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { user, tenantId } = await ctx(req);
    const { text } = await req.json();
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: Deno.env.get("LLM_MODEL") ?? "claude-sonnet-4-6", max_tokens: 1500, system: SYSTEM, messages: [{ role: "user", content: text }] }),
    });
    const j = await r.json();
    const extracted = JSON.parse(j.content[0].text.replace(/```json|```/g, "").trim());
    let match = null;
    const c = extracted.contact;
    if (c?.email) match = (await user.from("contacts").select("*").eq("email", c.email).maybeSingle()).data;
    else if (c?.full_name) match = (await user.from("contacts").select("*").ilike("full_name", `%${c.full_name}%`).limit(1)).data?.[0] ?? null;
    return new Response(JSON.stringify({ tenantId, extracted, possible_duplicate: match }), { headers: { ...cors, "content-type": "application/json" } });
  } catch (e) { return e instanceof Response ? e : new Response(String(e), { status: 500, headers: cors }); }
});
