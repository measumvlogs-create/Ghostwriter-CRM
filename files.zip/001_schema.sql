-- GhostWriter CRM: multi-tenant schema with RLS isolation
create table tenants(id uuid primary key default gen_random_uuid(), name text not null, fastn_tenant_id text, created_at timestamptz default now());
create table profiles(id uuid primary key references auth.users on delete cascade, tenant_id uuid references tenants not null, full_name text, email text, created_at timestamptz default now());
create table contacts(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, user_id uuid references auth.users, full_name text not null, email text, phone text, company text, job_title text, tags text[] default '{}', notes text, created_at timestamptz default now(), unique(tenant_id,email));
create table meetings(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, contact_id uuid references contacts, transcript text, summary text, requirements text, pain_points text, budget numeric, sentiment text, extracted jsonb, created_at timestamptz default now());
create table deals(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, contact_id uuid references contacts, title text not null, value numeric, currency text default 'USD', stage text default 'New Lead' check (stage in ('New Lead','Contacted','Qualified','Proposal Sent','Negotiation','Won','Lost')), expected_close date, notes text, created_at timestamptz default now());
create table tasks(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, contact_id uuid references contacts, deal_id uuid references deals, title text not null, description text, due_date date, priority text default 'medium', done boolean default false, created_at timestamptz default now());
create table timeline_events(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, contact_id uuid references contacts, kind text, body text, created_at timestamptz default now());
create table integrations(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, provider text not null check (provider in ('google_calendar','gmail','slack','google_drive','hubspot')), status text default 'not_connected', fastn_connection_id text, last_sync_at timestamptz, unique(tenant_id,provider));
create table workflow_runs(id uuid primary key default gen_random_uuid(), tenant_id uuid not null references tenants, workflow text, status text, result jsonb, created_at timestamptz default now());

create function current_tenant() returns uuid language sql stable security definer set search_path=public as $$ select tenant_id from profiles where id=auth.uid() $$;

do $$ declare t text; begin
 foreach t in array array['contacts','meetings','deals','tasks','timeline_events','integrations','workflow_runs'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy tenant_isolation on %I for all using (tenant_id=current_tenant()) with check (tenant_id=current_tenant())',t);
 end loop; end $$;
alter table tenants enable row level security;
create policy own_tenant on tenants for select using (id=current_tenant());
alter table profiles enable row level security;
create policy own_profile on profiles for select using (id=auth.uid());
