// Mints a per-tenant Fastn embed token server-side. Secrets never reach the browser.
// Set FASTN_EMBED_TOKEN_URL from your Fastn workspace docs/dashboard (not verified here).
import { cors, ctx } from "../_shared/auth.ts";
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { admin, tenantId } = await ctx(req);
    const { data: t } = await admin.from("tenants").select("name,fastn_tenant_id").eq("id", tenantId).single();
    const url = Deno.env.get("FASTN_EMBED_TOKEN_URL");
    if (!url) return new Response(JSON.stringify({ error: "FASTN_EMBED_TOKEN_URL not configured" }), { status: 501, headers: cors });
    const r = await fetch(url, {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("FASTN_API_KEY")}`, "content-type": "application/json" },
      body: JSON.stringify({ tenantId: t!.fastn_tenant_id ?? tenantId, tenantName: t!.name }),
    });
    const j = await r.json();
    if (!r.ok) return new Response(JSON.stringify({ error: "Fastn error", detail: j }), { status: 502, headers: cors });
    return new Response(JSON.stringify({ token: j.token ?? j.embedToken, iframe: "https://api.fastn.dev/v1/embed/iframe" }), { headers: { ...cors, "content-type": "application/json" } });
  } catch (e) { return e instanceof Response ? e : new Response(String(e), { status: 500, headers: cors }); }
});
