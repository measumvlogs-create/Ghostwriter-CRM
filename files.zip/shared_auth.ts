import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
export const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };
export async function ctx(req: Request) {
  const url = Deno.env.get("SUPABASE_URL")!;
  const user = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization")! } } });
  const { data: { user: u } } = await user.auth.getUser();
  if (!u) throw new Response("Unauthorized", { status: 401, headers: cors });
  const { data: p } = await user.from("profiles").select("tenant_id").eq("id", u.id).single();
  if (!p) throw new Response("No tenant", { status: 403, headers: cors });
  return { user, tenantId: p.tenant_id as string, admin: createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!) };
}
